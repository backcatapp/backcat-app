// src/lib/auth.ts
var STORAGE_KEY = "backcat_tokens";
function realmBase() {
  return `${"http://localhost:8080"}/realms/${"backcat"}`;
}
async function getStoredTokens() {
  const data = await chrome.storage.local.get(STORAGE_KEY);
  return data[STORAGE_KEY] ?? null;
}
async function clearTokens() {
  await chrome.storage.local.remove(STORAGE_KEY);
}
async function saveTokens(tokens) {
  await chrome.storage.local.set({ [STORAGE_KEY]: tokens });
}
async function refresh(tokens) {
  if (!tokens.refresh_token) throw new Error("no refresh token");
  const body = new URLSearchParams({
    grant_type: "refresh_token",
    client_id: "backcat-ext",
    refresh_token: tokens.refresh_token
  });
  const resp = await fetch(`${realmBase()}/protocol/openid-connect/token`, {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body
  });
  if (!resp.ok) throw new Error(`refresh failed (${resp.status})`);
  const json = await resp.json();
  const next = {
    access_token: json.access_token,
    refresh_token: json.refresh_token ?? tokens.refresh_token,
    id_token: json.id_token ?? tokens.id_token,
    expires_at: Date.now() + (json.expires_in ?? 300) * 1e3
  };
  await saveTokens(next);
  return next;
}
async function getAccessToken() {
  let tokens = await getStoredTokens();
  if (!tokens) return null;
  if (Date.now() < tokens.expires_at - 3e4) return tokens.access_token;
  try {
    tokens = await refresh(tokens);
    return tokens.access_token;
  } catch {
    await clearTokens();
    return null;
  }
}

// src/background.ts
var SERVE = "http://localhost:8000";
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false }).catch(() => {
});
chrome.action.onClicked.addListener((tab) => {
  if (tab.id == null) return;
  chrome.tabs.sendMessage(tab.id, { type: "close-backcat-panel" }).catch(() => {
  });
  chrome.sidePanel.open({ tabId: tab.id }).catch(() => {
  });
});
chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false }).catch(() => {
  });
});
async function authHeaders() {
  const token = await getAccessToken();
  const h = { "content-type": "application/json" };
  if (token) h.authorization = `Bearer ${token}`;
  return h;
}
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === "get-tokens") {
    getStoredTokens().then((t) => sendResponse(t)).catch(() => sendResponse(null));
    return true;
  }
  if (msg?.type === "get-access-token") {
    getAccessToken().then((token) => sendResponse({ token })).catch(() => sendResponse({ token: null }));
    return true;
  }
  if (msg?.type === "open-side-panel") {
    const tabId = sender.tab?.id;
    const openFor = (id) => {
      chrome.tabs.sendMessage(id, { type: "close-backcat-panel" }).catch(() => {
      });
      chrome.sidePanel.open({ tabId: id }).catch(() => {
      });
    };
    if (tabId != null) {
      openFor(tabId);
    } else {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]?.id != null) openFor(tabs[0].id);
      });
    }
    sendResponse({ ok: true });
    return true;
  }
  if (msg?.type === "api") {
    const { method, path, body } = msg;
    (async () => {
      try {
        const headers = await authHeaders();
        const resp = await fetch(`${SERVE}${path}`, {
          method: method || "GET",
          headers,
          body: body != null ? JSON.stringify(body) : void 0
        });
        const text = await resp.text();
        let data = null;
        try {
          data = text ? JSON.parse(text) : null;
        } catch {
          data = text;
        }
        sendResponse({ ok: resp.ok, status: resp.status, data });
      } catch (e) {
        sendResponse({
          ok: false,
          status: 0,
          error: e instanceof Error ? e.message : String(e)
        });
      }
    })();
    return true;
  }
  if (msg?.type === "ask-stream") {
    const tabId = sender.tab?.id;
    const { catalogId, question, requestId } = msg;
    (async () => {
      try {
        const headers = await authHeaders();
        const resp = await fetch(`${SERVE}/api/catalogs/${catalogId}/ask`, {
          method: "POST",
          headers,
          body: JSON.stringify({ question })
        });
        if (!resp.ok || !resp.body) {
          if (tabId != null) {
            chrome.tabs.sendMessage(tabId, {
              type: "ask-event",
              requestId,
              event: "error",
              data: { message: `request failed (${resp.status})`, code: resp.status }
            });
          }
          sendResponse({ ok: false });
          return;
        }
        const reader = resp.body.getReader();
        const decoder = new TextDecoder();
        let buffer = "";
        const emit = (event, data) => {
          if (tabId == null) return;
          chrome.tabs.sendMessage(tabId, { type: "ask-event", requestId, event, data });
        };
        for (; ; ) {
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          let idx;
          while ((idx = buffer.indexOf("\n\n")) !== -1) {
            const block = buffer.slice(0, idx);
            buffer = buffer.slice(idx + 2);
            let event = "";
            let data = "";
            for (const line of block.split("\n")) {
              if (line.startsWith("event: ")) event = line.slice(7).trim();
              else if (line.startsWith("data: ")) data += line.slice(6);
            }
            if (!event) continue;
            emit(event, data ? JSON.parse(data) : {});
          }
        }
        sendResponse({ ok: true });
      } catch (e) {
        if (tabId != null) {
          chrome.tabs.sendMessage(tabId, {
            type: "ask-event",
            requestId,
            event: "error",
            data: { message: e instanceof Error ? e.message : String(e) }
          });
        }
        sendResponse({ ok: false });
      }
    })();
    return true;
  }
  return false;
});
